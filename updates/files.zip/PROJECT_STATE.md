# Alef Bet — Project State

> Только актуальное. При изменении — заменять строку, не добавлять.

**Последнее обновление:** 21.07.2026
**Schema version:** 8 (канон `facts.{nodes,items}` + регенерируемое зеркало)
**Прод:** v0.14 (v8 задеплоен 20.07) · **dev:** beta.V1.1.4 (этапы 3–4, к деплою)

---

## v1.0-перестройка — статус

1. ✅ **Этап 1 — единый планировщик SM-2** (`planner.js`) — в проде.
2. ✅ **Этап 2 — единые факты v8 + миграция** (`facts.js`, `migrate.js`) — в проде.
   Гейт: миграция проверена на всех 15 живых юзерах (v1/v4/v5/v7).
3. ✅ **Этап 3 — движок упражнений** (`exercises.js` + `ExerciseSession`) — beta.V1.1.4.
4. ✅ **Этап 4 — схлопывание экранов** — beta.V1.1.4. Снесены хабы, лента «Новое»,
   узлы W1–5/P1–5, `checkWordsUnlock`. Колода букв — через CheatSheet/«Повторить буквы».
5. 🔲 **Этап 5 — вынос словарного прогресса** (`user_word_progress` в Supabase +
   чанкование CloudStorage). 🔴 Блокер цели 2000 слов — ДО залива колод.

**Заморозка контента снята** (перестройка экранного слоя завершена). Курс идёт по
`COURSE_MASTER_PLAN_v2.md`: Алеф 108 (готово 52), Бет 60, SL-трек книги
Коэн-Цедека вплетён в seq 53–108.

---

## Движок упражнений (этап 3 — АКТУАЛЬНО)

**`src/helpers/exercises.js`** — чистый реестр генераторов. Question:
`{gen, mode:'choice'|'typing', prompt, hebrew?, speak?, options?, answerId, itemId?}`.
Генераторы: `choice4` · `word_ru` · `word_he` · `no_nikud` · `typing` · `phrase_build`.
`buildSession(plan, rnd)` — сессия слоями; rnd инъектируется.
**`src/components/ui/ExerciseSession.jsx`** — единый рендерер (choice+typing+🔊).
Потребители: `LessonScreen` (практика = choice4), `ReadingScreen/LearnMode`
(word_ru), `TrainerMode` «🎯 Тренажёр» (word_he+no_nikud+typing).
⛔ Новый тип задания = генератор в реестре. Логику вопросов в экраны не возвращать.

## Схема v8 (этап 2 — АКТУАЛЬНО)

Канон — `stats.facts.{nodes,items}`; ключи элементов `l:`/`v:`/`w:`+id.
Зеркало (scores/blockScores/readingProgress/cardReviews/vowelReviews/weakLetters/
wordsStudied/wordsCorrect/progress) регенерируется `commit()`/`migrate()` —
экраны читают его, писать напрямую НЕЛЬЗЯ. Персист/CloudStorage хранит только
канон. Неизвестные counterKey переживают fold как `#<key>`.
Запись только через мутаторы `facts.js`: `setNodeScore`, `bumpNodeCounter`,
`reviewLetter/Vowel/Word`, `seenWord`, `answerWord`. Слияние — `mergeFacts`.
Миграция v1→v8 — `src/helpers/migrate.js` (чистый; `migrateThroughV7` — эталон
для инварианта).

## Граф курса (этап 4 — АКТУАЛЬНО)

`curriculum.js`: 94 узла (было 104; W1–5/P1–5 снесены). `deriveProgress` эмитит
`letters/sounds/reading/grammar-статусы`; матриц `words/phrases` больше нет.
Экраны: StudyScreen (Путь|Словарь; роутит letters/sounds/portion/grammar/sheet/
**cards**) · ReadingScreen (только DictView + solo-порции; лента снесена) ·
CheatSheet (+ «🃏 Карточки SM-2» для узлов букв) · CardsScreen (принимает onBack)
· HomeScreen (секции: Буквы/Огласовки/Словарь-единый-поток; «⏰ Повторить буквы»
→ колода). Удалены файлы: AlphabetScreen, GrammarScreen, WordsScreen.

## Тесты

`tests/smoke_v7.mjs` — **160 проверок**. Гонять после любых изменений:
```
npx esbuild tests/smoke_v7.mjs --bundle --format=esm --outfile=tests/.smoke.bundle.mjs
node tests/.smoke.bundle.mjs
```

## Инфраструктура (без изменений)

Repo `DannyJBill/Alef_Betbpt` · `https://alef-betbpt.vercel.app` · `@AlefBetBot`
· Supabase `pikoccutljmlkfondcxc` · Windows/PowerShell (команды раздельно).
API плоский (`api/`): sync, bot, cron, chat, admin, events, referral,
payments-create, payments-status. Vercel gotchas прежние.

## Известные рудименты / хвосты

- GameScreen топик «Слова»: счётчик пишется в снесённый узел W1 (канон хранит,
  вреда нет) — переосмыслить при Разговоре В.
- `recordWordSeen`, `recordWordResult` — экспорт жив, вызовов нет.
- `getDueWords()` не подключён к очереди «Повторить» (сортировка по wrong).
- `WORD_CATEGORIES` (500 слов) используется только GameScreen — судьба решится
  при слиянии реестров/Разговоре В.
