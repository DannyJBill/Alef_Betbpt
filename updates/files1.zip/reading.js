/**
 * reading.js — порции слов единого потока (schema v7.1).
 *
 * МЕХАНИКА: порция слов — полноценный узел графа курса (data/curriculum.js).
 * В зоне 0 (буквы+огласовки) порции ОБЯЗАТЕЛЬНЫ — следующий урок зоны
 * требует изучения порции предыдущего (100% доступных карточек).
 * Дальше (грамматика) порции открываются уроком, но не гейтят прогресс.
 *
 * Поля блока:
 *   id     — id узла в curriculum.js ('VL1.3') или 'R1.<seq>' для порций уроков
 *   seq    — порядок в ленте «Новое» (канонический путь курса)
 *   lesson — для порций грамматики: урок, который открывает порцию
 *   mode   — 'preview': порция до изучения никуда (транслит+аудио ведут чтение,
 *            допущен камац как «а»; N1.1/N1.2 потом формализуют знаки)
 *   items  — ТОЛЬКО новый материал (слово вводится в курсе ровно один раз)
 *   review — спираль повторения: ССЫЛКИ (id) на карточки предыдущих порций
 *
 * ПРАВИЛО ПЕРЕНОСА ИЗ МАСТЕРСКОЙ: дубль по plain → в review, не в items.
 * Историческая чистка v7.1: удалены дубли rp_26 (≈rw_56), rp_07 (≈rp_06), rw_53 (≈rw_49).
 * Черновики сверены 03.07.2026 (דָּג/גַּג, הָעִיר) — draft-флагов нет.
 */

export const READING_BLOCKS = [
  { id:"VL1.1", seq:2, title:"Первые слова", unlockLabel:"урок «Буквы гр.1»", mode:'preview',
    items: [
      { id:"rw_10", hebrew:"אַבָּא", plain:"אבא", transliteration:"аба", translation:"папа", english:"dad", type:"noun", audio:"rw_10.mp3" },
      { id:"rw_12", hebrew:"אַהֲבָה", plain:"אהבה", transliteration:"аhава", translation:"любовь", english:"love", type:"noun", audio:"rw_12.mp3" },
      { id:"rw_45", hebrew:"בָּאָה", plain:"באה", transliteration:"баа", translation:"приходит (ж.р.)", english:"comes (f)", type:"verb", audio:"rw_45.mp3" },
      { id:"rv_d01", hebrew:"דָּג", plain:"דג", transliteration:"даг", translation:"рыба", type:"word", audio:"rv_d01.mp3" },
      { id:"rv_d02", hebrew:"גַּג", plain:"גג", transliteration:"гаг", translation:"крыша", type:"word", audio:"rv_d02.mp3" },
    ],
    review: [],
  },
  { id:"VL1.2", seq:4, title:"Слова группы 2", unlockLabel:"урок «Буквы гр.2»", mode:'preview',
    items: [
      { id:"rw_07", hebrew:"הִיא", plain:"היא", transliteration:"hи", translation:"она", english:"she", type:"pronoun", audio:"rw_07.mp3" },
      { id:"rw_11", hebrew:"חָלָב", plain:"חלב", transliteration:"халав", translation:"молоко", english:"milk", type:"noun", audio:"rw_11.mp3" },
      { id:"rw_54", hebrew:"חַג", plain:"חג", transliteration:"хаг", translation:"праздник", english:"holiday", type:"noun", audio:"rw_54.mp3" },
      { id:"rw_55", hebrew:"טִיוּל", plain:"טיול", transliteration:"тиюль", translation:"прогулка / поход", english:"trip", type:"noun", audio:"rw_55.mp3" },
      { id:"rw_56", hebrew:"אוּלַי", plain:"אולי", transliteration:"улай", translation:"может быть", english:"maybe", type:"particle", audio:"rw_56.mp3" },
      { id:"rw_57", hebrew:"אַז", plain:"אז", transliteration:"аз", translation:"тогда", english:"then", type:"particle", audio:"rw_57.mp3" },
    ],
    review: [],
  },
  { id:"VL1.3", seq:10, title:"Слова: буквы гр.3", unlockLabel:"Буквы гр.3",
    items: [
      { id:"rw_01", hebrew:"אִימָא", plain:"אימא", transliteration:"има", translation:"мама", english:"mom", type:"noun", audio:"rw_01.mp3" },
      { id:"rw_02", hebrew:"יַיִן", plain:"יין", transliteration:"яин", translation:"вино", english:"wine", type:"noun", audio:"rw_02.mp3" },
      { id:"rw_03", hebrew:"מַיִם", plain:"מים", transliteration:"маим", translation:"вода", english:"water", type:"noun", audio:"rw_03.mp3" },
      { id:"rw_04", hebrew:"אֲנִי", plain:"אני", transliteration:"ани", translation:"я", english:"I", type:"pronoun", audio:"rw_04.mp3" },
      { id:"rw_13", hebrew:"חַם", plain:"חם", transliteration:"хам", translation:"горячий", english:"hot", type:"adj", audio:"rw_13.mp3" },
      { id:"rp_19", hebrew:"מִי", plain:"מי", transliteration:"ми", translation:"кто?", english:"who?", type:"phrase", audio:"rp_19.mp3" },
      { id:"rp_20", hebrew:"מַה", plain:"מה", transliteration:"ма", translation:"что?", english:"what?", type:"phrase", audio:"rp_20.mp3" },
      { id:"rp_16", hebrew:"כַּמָּה", plain:"כמה", transliteration:"кама", translation:"сколько?", english:"how much / how many?", type:"phrase", audio:"rp_16.mp3" },
      { id:"rp_18", hebrew:"לָמָה", plain:"למה", transliteration:"лама", translation:"почему?", english:"why?", type:"phrase", audio:"rp_18.mp3" },
      { id:"rp_33", hebrew:"חוּמוּס", plain:"חומוס", transliteration:"хумус", translation:"хумус", english:"hummus", type:"phrase", audio:"rp_33.mp3" },
      { id:"rp_34", hebrew:"בָּלָאגָן", plain:"בלאגן", transliteration:"балаган", translation:"беспорядок / балаган", english:"mess / chaos", type:"phrase", audio:"rp_34.mp3" },
      { id:"rw_33", hebrew:"עוּגָה", plain:"עוגה", transliteration:"уга", translation:"торт / пирог", english:"cake", type:"noun", audio:"rw_33.mp3" },
      { id:"rw_39", hebrew:"טָעִים", plain:"טעים", transliteration:"таим", translation:"вкусный", english:"tasty", type:"adj", audio:"rw_39.mp3" },
      { id:"rp_30", hebrew:"עֲלִייָּה", plain:"עלייה", transliteration:"алия", translation:"алия", english:"aliyah", type:"phrase", audio:"rp_30.mp3" },
    ],
    review: [],
  },
  { id:"VN1.3", seq:12, title:"Слова: Э-звуки", unlockLabel:"Огласовки Н3",
    items: [
      { id:"rw_09", hebrew:"לֶחֶם", plain:"לחם", transliteration:"лехем", translation:"хлеб", english:"bread", type:"noun", audio:"rw_09.mp3" },
      { id:"rp_25", hebrew:"הֵם", plain:"הם", transliteration:"hем", translation:"они (м.р.)", english:"they", type:"phrase", audio:"rp_25.mp3" },
      { id:"rw_16", hebrew:"יֶלֶד", plain:"ילד", transliteration:"йелед", translation:"мальчик", english:"boy", type:"noun", audio:"rw_16.mp3" },
      { id:"rw_18", hebrew:"זֶה", plain:"זה", transliteration:"зэ", translation:"это (м.р.)", english:"this (m)", type:"pronoun", audio:"rw_18.mp3" },
      { id:"rw_20", hebrew:"כֵּן", plain:"כן", transliteration:"кен", translation:"да", english:"yes", type:"particle", audio:"rw_20.mp3" },
      { id:"rw_23", hebrew:"כֶּלֶב", plain:"כלב", transliteration:"келев", translation:"собака", english:"dog", type:"noun", audio:"rw_23.mp3" },
      { id:"rw_25", hebrew:"מֶלֶך", plain:"מלך", transliteration:"мелех", translation:"король / царь", english:"king", type:"noun", audio:"rw_25.mp3" },
      { id:"rp_15", hebrew:"אֵיך", plain:"איך", transliteration:"эйх", translation:"как?", english:"how?", type:"phrase", audio:"rp_15.mp3" },
      { id:"rp_32", hebrew:"פָלָאפֶל", plain:"פלאפל", transliteration:"фалафель", translation:"фалафель", english:"falafel", type:"phrase", audio:"rp_32.mp3" },
      { id:"rw_34", hebrew:"יָפֶה", plain:"יפה", transliteration:"яфэ", translation:"красивый", english:"beautiful", type:"adj", audio:"rw_34.mp3" },
      { id:"rw_38", hebrew:"כֵּיף", plain:"כיף", transliteration:"кейф", translation:"кайф / весело", english:"fun", type:"noun", audio:"rw_38.mp3" },
      { id:"rp_11", hebrew:"אֵין בַּעַד מָה", plain:"אין בעד מה", transliteration:"эйн баад ма", translation:"не за что", english:"you're welcome", type:"phrase", audio:"rp_11.mp3" },
      { id:"rp_39", hebrew:"יַם הַמֶלַח", plain:"ים המלח", transliteration:"ям hамелах", translation:"Мёртвое море", english:"the Dead Sea", type:"phrase", audio:"rp_39.mp3" },
    ],
    review: [],
  },
  { id:"VL1.4", seq:14, title:"Слова: буквы гр.4", unlockLabel:"Буквы гр.4",
    items: [
      { id:"rw_05", hebrew:"אַת", plain:"את", transliteration:"ат", translation:"ты (ж.р.)", english:"you (f)", type:"pronoun", audio:"rw_05.mp3" },
      { id:"rw_06", hebrew:"אַתָה", plain:"אתה", transliteration:"ата", translation:"ты (м.р.)", english:"you (m)", type:"pronoun", audio:"rw_06.mp3" },
      { id:"rp_22", hebrew:"עֶרֶב", plain:"ערב", transliteration:"эрев", translation:"вечер", english:"evening", type:"phrase", audio:"rp_22.mp3" },
      { id:"rw_15", hebrew:"אִישָּׁה", plain:"אישה", transliteration:"иша", translation:"женщина / жена", english:"woman / wife", type:"noun", audio:"rw_15.mp3" },
      { id:"rw_21", hebrew:"גֶּבֶר", plain:"גבר", transliteration:"гевер", translation:"мужчина", english:"man", type:"noun", audio:"rw_21.mp3" },
      { id:"rw_24", hebrew:"שָׂמֵחַ", plain:"שמח", transliteration:"самеах", translation:"счастливый", english:"happy", type:"adj", audio:"rw_24.mp3" },
      { id:"rw_26", hebrew:"מַשָּׂאִית", plain:"משאית", transliteration:"масаит", translation:"грузовик", english:"truck", type:"noun", audio:"rw_26.mp3" },
      { id:"rp_17", hebrew:"מָתַי", plain:"מתי", transliteration:"матай", translation:"когда?", english:"when?", type:"phrase", audio:"rp_17.mp3" },
      { id:"rw_29", hebrew:"מִיץ", plain:"מיץ", transliteration:"миц", translation:"сок", english:"juice", type:"noun", audio:"rw_29.mp3" },
      { id:"rw_30", hebrew:"תַּפּוּז", plain:"תפוז", transliteration:"тапуз", translation:"апельсин", english:"orange", type:"noun", audio:"rw_30.mp3" },
      { id:"rw_31", hebrew:"סֵפֶר", plain:"ספר", transliteration:"сефер", translation:"книга", english:"book", type:"noun", audio:"rw_31.mp3" },
      { id:"rw_35", hebrew:"חָמוּץ", plain:"חמוץ", transliteration:"хамуц", translation:"кислый", english:"sour", type:"adj", audio:"rw_35.mp3" },
      { id:"rw_37", hebrew:"עָצוּב", plain:"עצוב", transliteration:"ацув", translation:"грустный", english:"sad", type:"adj", audio:"rw_37.mp3" },
      { id:"rw_40", hebrew:"רַע", plain:"רע", transliteration:"ра", translation:"плохой", english:"bad", type:"adj", audio:"rw_40.mp3" },
      { id:"rw_41", hebrew:"תַּפּוּחַ", plain:"תפוח", transliteration:"тапуах", translation:"яблоко", english:"apple", type:"noun", audio:"rw_41.mp3" },
      { id:"rp_31", hebrew:"קִיבּוּץ", plain:"קיבוץ", transliteration:"кибуц", translation:"кибуц", english:"kibbutz", type:"phrase", audio:"rp_31.mp3" },
    ],
    review: [],
  },
  { id:"VN1.4", seq:16, title:"Слова: О-звук", unlockLabel:"Огласовки Н4",
    items: [
      { id:"rw_08", hebrew:"לֹא", plain:"לא", transliteration:"ло", translation:"нет / не", english:"no / not", type:"particle", audio:"rw_08.mp3" },
      { id:"rw_14", hebrew:"יוֹנָה", plain:"יונה", transliteration:"йона", translation:"голубь", english:"pigeon / dove", type:"noun", audio:"rw_14.mp3" },
      { id:"rw_46", hebrew:"אוֹהֵב", plain:"אוהב", transliteration:"оhев", translation:"любит (м.р.)", english:"loves (m)", type:"verb", audio:"rw_46.mp3" },
      { id:"rp_01", hebrew:"שָׁלוֹם", plain:"שלום", transliteration:"шалом", translation:"привет / до свидания / мир", english:"hello / goodbye / peace", type:"phrase", audio:"rp_01.mp3" },
      { id:"rp_02", hebrew:"תּוֹדָה", plain:"תודה", transliteration:"тода", translation:"спасибо", english:"thanks", type:"phrase", audio:"rp_02.mp3" },
      { id:"rp_21", hebrew:"בּוֹקֶר", plain:"בוקר", transliteration:"бокер", translation:"утро", english:"morning", type:"phrase", audio:"rp_21.mp3" },
      { id:"rw_19", hebrew:"זֹאת", plain:"זאת", transliteration:"зот", translation:"это (ж.р.)", english:"this (f)", type:"pronoun", audio:"rw_19.mp3" },
      { id:"rw_27", hebrew:"אֱגוֹז", plain:"אגוז", transliteration:"эгоз", translation:"орех", english:"nut", type:"noun", audio:"rw_27.mp3" },
      { id:"rw_28", hebrew:"אוֹרֶז", plain:"אורז", transliteration:"орез", translation:"рис", english:"rice", type:"noun", audio:"rw_28.mp3" },
      { id:"rw_48", hebrew:"אוֹכֵל", plain:"אוכל", transliteration:"охел", translation:"ест (м.р.)", english:"eats (m)", type:"verb", audio:"rw_48.mp3" },
      { id:"rw_49", hebrew:"רוֹאֶה", plain:"רואה", transliteration:"роэ", translation:"видит (м.р.)", english:"sees (m)", type:"verb", audio:"rw_49.mp3" },
      { id:"rw_50", hebrew:"שׁוֹתֶה", plain:"שותה", transliteration:"шотэ", translation:"пьёт (м.р.)", english:"drinks (m)", type:"verb", audio:"rw_50.mp3" },
      { id:"rp_10", hebrew:"תוֹדָה רָבָּה", plain:"תודה רבה", transliteration:"тода раба", translation:"большое спасибо", english:"thank you very much", type:"phrase", audio:"rp_10.mp3" },
      { id:"rp_14", hebrew:"אֵיפֹה", plain:"איפה", transliteration:"эйфо", translation:"где?", english:"where?", type:"phrase", audio:"rp_14.mp3" },
      { id:"rp_35", hebrew:"מַה קוֹרֶה?", plain:"מה קורה?", transliteration:"ма корэ?", translation:"что происходит?", english:"what's happening?", type:"phrase", audio:"rp_35.mp3" },
      { id:"rw_32", hebrew:"טוֹב", plain:"טוב", transliteration:"тов", translation:"хорошо / хороший", english:"good", type:"adj", audio:"rw_32.mp3" },
      { id:"rw_36", hebrew:"מָתוֹק", plain:"מתוק", transliteration:"маток", translation:"сладкий", english:"sweet", type:"adj", audio:"rw_36.mp3" },
      { id:"rw_42", hebrew:"עוֹף", plain:"עוף", transliteration:"оф", translation:"птица / курица", english:"chicken / bird", type:"noun", audio:"rw_42.mp3" },
      { id:"rw_43", hebrew:"עִיתּוֹן", plain:"עיתון", transliteration:"итон", translation:"газета", english:"newspaper", type:"noun", audio:"rw_43.mp3" },
      { id:"rw_51", hebrew:"קוֹרֵא", plain:"קורא", transliteration:"корэ", translation:"читает (м.р.)", english:"reads (m)", type:"verb", audio:"rw_51.mp3" },
      { id:"rw_52", hebrew:"רוֹצֶה", plain:"רוצה", transliteration:"роцэ", translation:"хочет (м.р.)", english:"wants (m)", type:"verb", audio:"rw_52.mp3" },
      { id:"rp_13", hebrew:"מַזָּל טוֹב", plain:"מזל טוב", transliteration:"мазаль тов", translation:"поздравляю!", english:"congratulations", type:"phrase", audio:"rp_13.mp3" },
      { id:"rp_29", hebrew:"עוֹלֶה חָדָשׁ", plain:"עולה חדש", transliteration:"оле хадаш", translation:"новый репатриант", english:"new immigrant", type:"phrase", audio:"rp_29.mp3" },
      { id:"rp_38", hebrew:"הַיָּם הָאָדוֹם", plain:"הים האדום", transliteration:"hайям hаадом", translation:"Красное море", english:"the Red Sea", type:"phrase", audio:"rp_38.mp3" },
    ],
    review: [],
  },
  { id:"VN1.5", seq:20, title:"Слова: шва", unlockLabel:"Огласовки Н5",
    items: [
      { id:"rp_23", hebrew:"לַיְלָה", plain:"לילה", transliteration:"лайла", translation:"ночь", english:"night", type:"phrase", audio:"rp_23.mp3" },
      { id:"rp_24", hebrew:"אֲנַחְנוּ", plain:"אנחנו", transliteration:"анахну", translation:"мы", english:"we", type:"phrase", audio:"rp_24.mp3" },
      { id:"rw_17", hebrew:"יַלְדָה", plain:"ילדה", transliteration:"ялда", translation:"девочка", english:"girl", type:"noun", audio:"rw_17.mp3" },
      { id:"rw_22", hebrew:"דֶּרֶךְ", plain:"דרך", transliteration:"дерех", translation:"дорога / путь", english:"way / road", type:"noun", audio:"rw_22.mp3" },
      { id:"rw_47", hebrew:"הוֹלֵךְ", plain:"הולך", transliteration:"hолех", translation:"идёт (м.р.)", english:"walks (m)", type:"verb", audio:"rw_47.mp3" },
      { id:"rp_03", hebrew:"בְּבַקָשָׁה", plain:"בבקשה", transliteration:"бевакаша", translation:"пожалуйста / не за что", english:"please / you're welcome", type:"phrase", audio:"rp_03.mp3" },
      { id:"rp_04", hebrew:"סְלִיחָה", plain:"סליחה", transliteration:"слиха", translation:"извините / прости", english:"sorry / excuse me", type:"phrase", audio:"rp_04.mp3" },
      { id:"rp_05", hebrew:"בְּסֵדֶר", plain:"בסדר", transliteration:"бесэдер", translation:"всё в порядке / окей", english:"alright / fine", type:"phrase", audio:"rp_05.mp3" },
      { id:"rp_06", hebrew:"מַה שְׁלוֹמְךָ?", plain:"מה שלומך?", transliteration:"ма шломха?", translation:"как дела? (м.р.)", english:"how are you? (m)", type:"phrase", audio:"rp_06.mp3" },
      { id:"rp_08", hebrew:"בָּרוּךְ הַבָּא", plain:"ברוך הבא", transliteration:"барух hаба", translation:"добро пожаловать", english:"welcome", type:"phrase", audio:"rp_08.mp3" },
      { id:"rp_09", hebrew:"מַה נִשְׁמַע?", plain:"מה נשמע?", transliteration:"ма нишма?", translation:"что слышно? / как дела?", english:"what's up?", type:"phrase", audio:"rp_09.mp3" },
      { id:"rp_27", hebrew:"עִבְרִית", plain:"עברית", transliteration:"иврит", translation:"иврит", english:"Hebrew", type:"phrase", audio:"rp_27.mp3" },
      { id:"rp_36", hebrew:"לְהִתְרָאוֹת", plain:"להתראות", transliteration:"леhитраот", translation:"до свидания", english:"see you later", type:"phrase", audio:"rp_36.mp3" },
      { id:"rw_44", hebrew:"אֲפַרְסֵק", plain:"אפרסק", transliteration:"афарсек", translation:"персик", english:"peach", type:"noun", audio:"rw_44.mp3" },
      { id:"rp_12", hebrew:"בְּהַצְלָחָה", plain:"בהצלחה", transliteration:"бехацлаха", translation:"удачи!", english:"good luck", type:"phrase", audio:"rp_12.mp3" },
      { id:"rp_28", hebrew:"אוּלְפָּן", plain:"אולפן", transliteration:"ульпан", translation:"ульпан", english:"ulpan", type:"phrase", audio:"rp_28.mp3" },
      { id:"rp_37", hebrew:"שַׁקְשׁוּקָה", plain:"שקשוקה", transliteration:"шакшука", translation:"шакшука", english:"shakshuka", type:"phrase", audio:"rp_37.mp3" },
    ],
    review: [],
  },
  // ── C0 — открывается после урока ──
  { id:"R1.20", seq:120, lesson:"C0", title:"Именное предложение",
    items: [
      { id:"r1_c0_01", hebrew:"הוּא", plain:"הוא", transliteration:"hu", translation:"он", type:"word", lesson:"C0", audio:"r1_c0_01.mp3" },
      { id:"r1_c0_03", hebrew:"מוֹרָה", plain:"מורה", transliteration:"moráh", translation:"учительница", type:"word", lesson:"C0", audio:"r1_c0_03.mp3" },
      { id:"r1_c0_04", hebrew:"גָּדוֹל", plain:"גדול", transliteration:"gadól", translation:"большой", type:"word", lesson:"C0", audio:"r1_c0_04.mp3" },
      { id:"r1_c0_05", hebrew:"הַכֶּלֶב גָּדוֹל", plain:"הכלב גדול", transliteration:"ha-kélev gadól", translation:"собака большая (Рекс большой)", type:"phrase", lesson:"C0", audio:"r1_c0_05.mp3" },
      { id:"r1_c0_06", hebrew:"הִיא מוֹרָה", plain:"היא מורה", transliteration:"hi moráh", translation:"она учительница (Майя — учительница)", type:"phrase", lesson:"C0", audio:"r1_c0_06.mp3" },
      { id:"r1_c0_08", hebrew:"הוּא יֶלֶד", plain:"הוא ילד", transliteration:"hu yéled", translation:"он мальчик (Ноам — мальчик)", type:"phrase", lesson:"C0", audio:"r1_c0_08.mp3" },
      { id:"r1_c0_09", hebrew:"הַבַּיִת גָּדוֹל", plain:"הבית גדול", transliteration:"ha-báyit gadól", translation:"дом большой (новый дом семьи большой)", type:"phrase", lesson:"C0", audio:"r1_c0_09.mp3" },
    ],
    review: ["rw_07", "rw_16"],
  },
  // ── M1.1 — открывается после урока ──
  { id:"R1.21", seq:121, lesson:"M1.1", title:"Артикль הַ",
    items: [
      { id:"r1_m11_01", hebrew:"בַּיִת", plain:"בית", transliteration:"báyit", translation:"дом", type:"word", lesson:"M1.1", audio:"r1_m11_01.mp3" },
      { id:"r1_m11_02", hebrew:"הַבַּיִת", plain:"הבית", transliteration:"ha-báyit", translation:"тот дом (определённый)", type:"word", lesson:"M1.1", audio:"r1_m11_02.mp3" },
      { id:"r1_m11_03", hebrew:"הַכֶּלֶב", plain:"הכלב", transliteration:"ha-kélev", translation:"та собака (Рекс!)", type:"word", lesson:"M1.1", audio:"r1_m11_03.mp3" },
      { id:"r1_m11_04", hebrew:"חָדָשׁ", plain:"חדש", transliteration:"hadásh", translation:"новый", type:"word", lesson:"M1.1", audio:"r1_m11_04.mp3" },
      { id:"r1_m11_05", hebrew:"קָטָן", plain:"קטן", transliteration:"katán", translation:"маленький", type:"word", lesson:"M1.1", audio:"r1_m11_05.mp3" },
      { id:"r1_m11_06", hebrew:"הַבַּיִת חָדָשׁ", plain:"הבית חדש", transliteration:"ha-báyit hadásh", translation:"дом новый — Майя говорит соседям про новый дом семьи", type:"phrase", lesson:"M1.1", audio:"r1_m11_06.mp3" },
      { id:"r1_m11_07", hebrew:"הַיֶּלֶד קָטָן", plain:"הילד קטן", transliteration:"ha-yéled katán", translation:"мальчик маленький — Ноам ещё маленький", type:"phrase", lesson:"M1.1", audio:"r1_m11_07.mp3" },
    ],
    review: ["rw_23", "rw_16", "r1_c0_04"],
  },
  // ── C1 — открывается после урока ──
  { id:"R1.22", seq:122, lesson:"C1", title:"יֵשׁ / אֵין — есть/нет",
    items: [
      { id:"r1_c1_01", hebrew:"יֵשׁ", plain:"יש", transliteration:"yesh", translation:"есть (что-то имеется)", type:"word", lesson:"C1", audio:"r1_c1_01.mp3" },
      { id:"r1_c1_02", hebrew:"אֵין", plain:"אין", transliteration:"ein", translation:"нет (чего-то нет)", type:"word", lesson:"C1", audio:"r1_c1_02.mp3" },
      { id:"r1_c1_03", hebrew:"יֵשׁ לִי", plain:"יש לי", transliteration:"yesh li", translation:"у меня есть", type:"phrase", lesson:"C1", audio:"r1_c1_03.mp3" },
      { id:"r1_c1_04", hebrew:"אֵין לִי", plain:"אין לי", transliteration:"ein li", translation:"у меня нет", type:"phrase", lesson:"C1", audio:"r1_c1_04.mp3" },
      { id:"r1_c1_05", hebrew:"יֵשׁ לְךָ כֶּלֶב?", plain:"יש לך כלב?", transliteration:"yesh le-kha kelev?", translation:"У тебя есть собака? — Ноам спрашивает соседа Шимона", type:"phrase", lesson:"C1", audio:"r1_c1_05.mp3" },
      { id:"r1_c1_06", hebrew:"יֵשׁ לִי כֶּלֶב.", plain:"יש לי כלב.", transliteration:"yesh li kelev.", translation:"У меня есть собака. — Шимон улыбается: у него тоже есть пёс", type:"phrase", lesson:"C1", audio:"r1_c1_06.mp3" },
      { id:"r1_c1_07", hebrew:"אֵין לִי כֶּלֶב, יֵשׁ לִי בַּיִת.", plain:"אין לי כלב, יש לי בית.", transliteration:"ein li kelev, yesh li bayit.", translation:"У меня нет собаки, у меня есть дом. — Малка смеётся: дом есть, собаки нет", type:"phrase", lesson:"C1", audio:"r1_c1_07.mp3" },
    ],
    review: [],
  },
  // ── M1.2 — открывается после урока ──
  { id:"R1.23", seq:123, lesson:"M1.2", title:"Артикль перед гортанными",
    items: [
      { id:"r1_m12_01", hebrew:"הָאֵם", plain:"האם", transliteration:"ха-эм", translation:"мама (с артиклем). Майя — הָאֵם. Перед א гласная артикля — а долгое.", type:"word", lesson:"M1.2", audio:"r1_m12_01.mp3" },
      { id:"r1_m12_02", hebrew:"הָאִישׁ", plain:"האיש", transliteration:"ха-иш", translation:"мужчина, муж (с артиклем). Даниэль — הָאִישׁ. Перед א артикль הָ.", type:"word", lesson:"M1.2", audio:"r1_m12_02.mp3" },
      { id:"r1_m12_03", hebrew:"הֶחָלָב", plain:"החלב", transliteration:"хе-халав", translation:"молоко (с артиклем). Майя ставит הֶחָלָב на стол. Перед ח артикль הֶ.", type:"word", lesson:"M1.2", audio:"r1_m12_03.mp3" },
      { id:"r1_m12_04", hebrew:"הָעִיר", plain:"העיר", transliteration:"ха-ир", translation:"город (с артиклем). Тель-Авив — הָעִיר. Перед עִ (не камац) артикль הָ.", type:"word", lesson:"M1.2", audio:"r1_m12_04.mp3" },
      { id:"r1_m12_05", hebrew:"הָאֵם בַּבַּיִת", plain:"האם בבית", transliteration:"ха-эм ба-байт", translation:"Мама дома. Майя — הָאֵם — дома с детьми.", type:"phrase", lesson:"M1.2", audio:"r1_m12_05.mp3" },
      { id:"r1_m12_06", hebrew:"הֶחָלָב עַל הַשֻּׁלְחָן", plain:"החלב על השלחן", transliteration:"хе-халав аль ха-шшулхан", translation:"Молоко на столе. Майя поставила הֶחָלָב на הַשֻּׁלְחָן.", type:"phrase", lesson:"M1.2", audio:"r1_m12_06.mp3" },
      { id:"r1_m12_07", hebrew:"הָאִישׁ בָּרְחוֹב", plain:"האיש ברחוב", transliteration:"ха-иш ба-рехов", translation:"Мужчина на улице. Даниэль — הָאִישׁ — вышел на הָרְחוֹב.", type:"phrase", lesson:"M1.2", audio:"r1_m12_07.mp3" },
    ],
    review: [],
  },
  // ── M1.3 — открывается после урока ──
  { id:"R1.24", seq:124, lesson:"M1.3", title:"Женский род",
    items: [
      { id:"r1_m13_03", hebrew:"שַׁבָּת", plain:"שבת", transliteration:"sha-bát", translation:"суббота — вся семья дома בְּשַׁבָּת", type:"word", lesson:"M1.3", audio:"r1_m13_03.mp3" },
      { id:"r1_m13_05", hebrew:"אֱמֶת", plain:"אמת", transliteration:"e-met", translation:"правда, истина — оканчивается на ת, женский род. Даниэль говорит: «זֹאת אֱמֶת» — это правда", type:"word", lesson:"M1.3", audio:"r1_m13_05.mp3" },
      { id:"r1_m13_07", hebrew:"זֹאת הַיַּלְדָּה שֶׁלִּי", plain:"זאת הילדה שלי", transliteration:"zot ha-yal-dá she-lí", translation:"это моя девочка — Даниэль говорит соседу Шимону про Тамар", type:"phrase", lesson:"M1.3", audio:"r1_m13_07.mp3" },
    ],
    review: ["rw_17", "r1_c0_03", "rw_12", "rw_22"],
  },
  // ── M1.4 — открывается после урока ──
  { id:"R1.25", seq:125, lesson:"M1.4", title:"Артикль + род — синтез",
    items: [
      { id:"r1_m14_02", hebrew:"גְּדוֹלָה", plain:"גדולה", transliteration:"gdolá", translation:"большая (ж.р.) — форма от גָּדוֹל для существительных женского рода", type:"word", lesson:"M1.4", audio:"r1_m14_02.mp3" },
      { id:"r1_m14_03", hebrew:"הַיֶּלֶד הַגָּדוֹל", plain:"הילד הגדול", transliteration:"ha-yéled ha-gadól", translation:"тот большой мальчик — Малка говорит о Ноаме: «הַיֶּלֶד הַגָּדוֹל бежит!»", type:"phrase", lesson:"M1.4", audio:"r1_m14_03.mp3" },
      { id:"r1_m14_04", hebrew:"הַיַּלְדָּה הַגְּדוֹלָה", plain:"הילדה הגדולה", transliteration:"ha-yaldá ha-gdolá", translation:"та большая девочка — Шимон говорит о Тамар: «הַיַּלְדָּה הַגְּדוֹלָה — Тамар»", type:"phrase", lesson:"M1.4", audio:"r1_m14_04.mp3" },
      { id:"r1_m14_05", hebrew:"הַכֶּלֶב הַגָּדוֹל", plain:"הכלב הגדול", transliteration:"ha-kélev ha-gadól", translation:"та большая собака — Даниэль смеётся: «זֶה רֶקְס — הַכֶּלֶב הַגָּדוֹל!»", type:"phrase", lesson:"M1.4", audio:"r1_m14_05.mp3" },
      { id:"r1_m14_06", hebrew:"הַבַּיִת הֶחָדָשׁ", plain:"הבית החדש", transliteration:"ha-báyit he-hadásh", translation:"тот новый дом — Майя говорит соседям: «הַבַּיִת הֶחָדָשׁ שֶׁלָּנוּ»", type:"phrase", lesson:"M1.4", audio:"r1_m14_06.mp3" },
    ],
    review: ["r1_c0_04", "r1_m13_07"],
  },
  // ── CH1.1 — открывается после урока ──
  { id:"R1.26", seq:126, lesson:"CH1.1", title:"Числа 1–5 (м.р.)",
    items: [
      { id:"r1_ch11_01", hebrew:"אֶחָד", plain:"אחד", transliteration:"эхад", translation:"один (м.р.)", type:"word", lesson:"CH1.1", audio:"r1_ch11_01.mp3" },
      { id:"r1_ch11_02", hebrew:"שְׁנַיִם", plain:"שנים", transliteration:"шнаим", translation:"два (м.р.)", type:"word", lesson:"CH1.1", audio:"r1_ch11_02.mp3" },
      { id:"r1_ch11_03", hebrew:"שְׁלֹשָׁה", plain:"שלשה", transliteration:"шлоша", translation:"три (м.р.)", type:"word", lesson:"CH1.1", audio:"r1_ch11_03.mp3" },
      { id:"r1_ch11_04", hebrew:"אַרְבָּעָה", plain:"ארבעה", transliteration:"арбаа", translation:"четыре (м.р.)", type:"word", lesson:"CH1.1", audio:"r1_ch11_04.mp3" },
      { id:"r1_ch11_05", hebrew:"חֲמִשָּׁה", plain:"חמשה", transliteration:"хамиша", translation:"пять (м.р.)", type:"word", lesson:"CH1.1", audio:"r1_ch11_05.mp3" },
      { id:"r1_ch11_06", hebrew:"יֶלֶד אֶחָד", plain:"ילד אחד", transliteration:"йэлед эхад", translation:"один мальчик — «один» стоит после слова. Ноам — йэлед эхад", type:"phrase", lesson:"CH1.1", audio:"r1_ch11_06.mp3" },
      { id:"r1_ch11_07", hebrew:"כֶּלֶב אֶחָד", plain:"כלב אחד", transliteration:"кэлев эхад", translation:"одна собака — Рекс! (кэлев — м.р.)", type:"phrase", lesson:"CH1.1", audio:"r1_ch11_07.mp3" },
    ],
    review: ["rw_16", "rw_23"],
  },
  // ── CH1.2 — открывается после урока ──
  { id:"R1.27", seq:127, lesson:"CH1.2", title:"Числа 1–5 (ж.р.)",
    items: [
      { id:"r1_ch12_01", hebrew:"אַחַת", plain:"אחת", transliteration:"ахат", translation:"одна (ж.р.)", type:"word", lesson:"CH1.2", audio:"r1_ch12_01.mp3" },
      { id:"r1_ch12_02", hebrew:"שְׁתַּיִם", plain:"שתים", transliteration:"штаим", translation:"две (ж.р.)", type:"word", lesson:"CH1.2", audio:"r1_ch12_02.mp3" },
      { id:"r1_ch12_03", hebrew:"שָׁלֹשׁ", plain:"שלש", transliteration:"шалош", translation:"три (ж.р.)", type:"word", lesson:"CH1.2", audio:"r1_ch12_03.mp3" },
      { id:"r1_ch12_04", hebrew:"אַרְבַּע", plain:"ארבע", transliteration:"арба", translation:"четыре (ж.р.)", type:"word", lesson:"CH1.2", audio:"r1_ch12_04.mp3" },
      { id:"r1_ch12_05", hebrew:"חָמֵשׁ", plain:"חמש", transliteration:"хамеш", translation:"пять (ж.р.)", type:"word", lesson:"CH1.2", audio:"r1_ch12_05.mp3" },
      { id:"r1_ch12_06", hebrew:"יַלְדָּה אַחַת", plain:"ילדה אחת", transliteration:"ялда ахат", translation:"одна девочка — Тамар! (ялда — ж.р.)", type:"phrase", lesson:"CH1.2", audio:"r1_ch12_06.mp3" },
    ],
    review: ["r1_ch11_01", "r1_ch11_03", "rw_17"],
  },
  // ── CH1.3 — открывается после урока ──
  { id:"R1.28", seq:128, lesson:"CH1.3", title:"Числа 6–10 (м.р.)",
    items: [
      { id:"r1_ch13_01", hebrew:"שִׁשָּׁה", plain:"ששה", transliteration:"шиша", translation:"шесть (м.р.)", type:"word", lesson:"CH1.3", audio:"r1_ch13_01.mp3" },
      { id:"r1_ch13_02", hebrew:"שִׁבְעָה", plain:"שבעה", transliteration:"шивъа", translation:"семь (м.р.)", type:"word", lesson:"CH1.3", audio:"r1_ch13_02.mp3" },
      { id:"r1_ch13_03", hebrew:"שְׁמֹנָה", plain:"שמנה", transliteration:"шмона", translation:"восемь (м.р.)", type:"word", lesson:"CH1.3", audio:"r1_ch13_03.mp3" },
      { id:"r1_ch13_04", hebrew:"תִּשְׁעָה", plain:"תשעה", transliteration:"тишъа", translation:"девять (м.р.)", type:"word", lesson:"CH1.3", audio:"r1_ch13_04.mp3" },
      { id:"r1_ch13_05", hebrew:"עֲשָׂרָה", plain:"עשרה", transliteration:"асара", translation:"десять (м.р.)", type:"word", lesson:"CH1.3", audio:"r1_ch13_05.mp3" },
    ],
    review: ["r1_ch11_05", "r1_ch12_01"],
  },
  // ── G1.2 — открывается после урока ──
  { id:"R1.30", seq:130, lesson:"G1.2", title:"паАль м.р. — новые глаголы",
    items: [
      { id:"r1_g12_01", hebrew:"יוֹשֵׁב", plain:"יושב", transliteration:"йошев", translation:"сидит (м.р.)", type:"word", lesson:"G1.2", audio:"r1_g12_01.mp3" },
      { id:"r1_g12_02", hebrew:"עוֹמֵד", plain:"עומד", transliteration:"омед", translation:"стоит (м.р.)", type:"word", lesson:"G1.2", audio:"r1_g12_02.mp3" },
      { id:"r1_g12_03", hebrew:"יוֹדֵעַ", plain:"יודע", transliteration:"йодэа", translation:"знает (м.р.)", type:"word", lesson:"G1.2", audio:"r1_g12_03.mp3" },
      { id:"r1_g12_04", hebrew:"יָכוֹל", plain:"יכול", transliteration:"яхоль", translation:"может (м.р.)", type:"word", lesson:"G1.2", audio:"r1_g12_04.mp3" },
      { id:"r1_g12_05", hebrew:"גָּר", plain:"גר", transliteration:"гар", translation:"живёт где-то (м.р.)", type:"word", lesson:"G1.2", audio:"r1_g12_05.mp3" },
      { id:"r1_g12_06", hebrew:"אֲנִי יוֹדֵעַ", plain:"אני יודע", transliteration:"ани йодэа", translation:"я знаю (говорит мужчина)", type:"phrase", lesson:"G1.2", audio:"r1_g12_06.mp3" },
    ],
    review: ["rw_47", "rw_48", "r1_c0_01"],
  },
  // ── G1.3 — открывается после урока ──
  { id:"R1.31", seq:131, lesson:"G1.3", title:"паАль ж.р. — женские формы",
    items: [
      { id:"r1_g13_01", hebrew:"הוֹלֶכֶת", plain:"הולכת", transliteration:"hолехет", translation:"идёт (ж.р.)", type:"word", lesson:"G1.3", audio:"r1_g13_01.mp3" },
      { id:"r1_g13_02", hebrew:"אוֹכֶלֶת", plain:"אוכלת", transliteration:"охэлет", translation:"ест (ж.р.)", type:"word", lesson:"G1.3", audio:"r1_g13_02.mp3" },
      { id:"r1_g13_03", hebrew:"יוֹשֶׁבֶת", plain:"יושבת", transliteration:"йошевет", translation:"сидит (ж.р.)", type:"word", lesson:"G1.3", audio:"r1_g13_03.mp3" },
      { id:"r1_g13_04", hebrew:"אוֹהֶבֶת", plain:"אוהבת", transliteration:"оhевет", translation:"любит (ж.р.)", type:"word", lesson:"G1.3", audio:"r1_g13_04.mp3" },
      { id:"r1_g13_05", hebrew:"גָּרָה", plain:"גרה", transliteration:"гара", translation:"живёт где-то (ж.р.)", type:"word", lesson:"G1.3", audio:"r1_g13_05.mp3" },
      { id:"r1_g13_06", hebrew:"הִיא הוֹלֶכֶת", plain:"היא הולכת", transliteration:"hи hолехет", translation:"она идёт — Майя на работу", type:"phrase", lesson:"G1.3", audio:"r1_g13_06.mp3" },
    ],
    review: ["rw_50", "rw_52", "rw_07"],
  },
  // ── G1.4 — открывается после урока ──
  { id:"R1.32", seq:132, lesson:"G1.4", title:"Первые предложения",
    items: [
      { id:"r1_g14_01", hebrew:"הוּא אוֹכֵל לֶחֶם", plain:"הוא אוכל לחם", transliteration:"hу охэль лэхем", translation:"он ест хлеб", type:"phrase", lesson:"G1.4", audio:"r1_g14_01.mp3" },
      { id:"r1_g14_02", hebrew:"הִיא אוֹכֶלֶת עוּגָה", plain:"היא אוכלת עוגה", transliteration:"hи охэлет уга", translation:"она ест торт — Тамар в шаббат", type:"phrase", lesson:"G1.4", audio:"r1_g14_02.mp3" },
      { id:"r1_g14_03", hebrew:"הוּא שׁוֹתֶה מִיץ", plain:"הוא שותה מיץ", transliteration:"hу шотэ миц", translation:"он пьёт сок", type:"phrase", lesson:"G1.4", audio:"r1_g14_03.mp3" },
      { id:"r1_g14_04", hebrew:"אַתָּה קוֹרֵא סֵפֶר", plain:"אתה קורא ספר", transliteration:"ата корэ сэфер", translation:"ты читаешь книгу (м.р.)", type:"phrase", lesson:"G1.4", audio:"r1_g14_04.mp3" },
      { id:"r1_g14_05", hebrew:"הוּא רוֹאֶה כֶּלֶב", plain:"הוא רואה כלב", transliteration:"hу роэ кэлев", translation:"он видит собаку — Рекса!", type:"phrase", lesson:"G1.4", audio:"r1_g14_05.mp3" },
    ],
    review: ["rw_49", "rw_51", "rw_09"],
  },
  // ── G1.5 — открывается после урока ──
  { id:"R1.33", seq:133, lesson:"G1.5", title:"Отрицание לֹא",
    items: [
      { id:"r1_g15_01", hebrew:"אֲנִי לֹא רוֹצֶה", plain:"אני לא רוצה", transliteration:"ани ло роцэ", translation:"я не хочу (м.р.) — главная фраза Ноама", type:"phrase", lesson:"G1.5", audio:"r1_g15_01.mp3" },
      { id:"r1_g15_02", hebrew:"אֲנִי לֹא יוֹדֵעַ", plain:"אני לא יודע", transliteration:"ани ло йодэа", translation:"я не знаю (м.р.)", type:"phrase", lesson:"G1.5", audio:"r1_g15_02.mp3" },
      { id:"r1_g15_03", hebrew:"הוּא לֹא אוֹכֵל עוֹף", plain:"הוא לא אוכל עוף", transliteration:"hу ло охэль оф", translation:"он не ест курицу", type:"phrase", lesson:"G1.5", audio:"r1_g15_03.mp3" },
      { id:"r1_g15_04", hebrew:"הִיא לֹא הוֹלֶכֶת", plain:"היא לא הולכת", transliteration:"hи ло hолехет", translation:"она не идёт — Тамар остаётся дома", type:"phrase", lesson:"G1.5", audio:"r1_g15_04.mp3" },
    ],
    review: ["rw_08", "r1_g12_03", "r1_g13_01"],
  },
  // ── G1.6 — открывается после урока ──
  { id:"R1.34", seq:134, lesson:"G1.6", title:"10 глаголов — синтез",
    items: [
      { id:"r1_g16_01", hebrew:"עוֹמֶדֶת", plain:"עומדת", transliteration:"омедет", translation:"стоит (ж.р.)", type:"word", lesson:"G1.6", audio:"r1_g16_01.mp3" },
      { id:"r1_g16_02", hebrew:"יוֹדַעַת", plain:"יודעת", transliteration:"йодаат", translation:"знает (ж.р.)", type:"word", lesson:"G1.6", audio:"r1_g16_02.mp3" },
      { id:"r1_g16_03", hebrew:"יְכוֹלָה", plain:"יכולה", transliteration:"ехола", translation:"может (ж.р.)", type:"word", lesson:"G1.6", audio:"r1_g16_03.mp3" },
      { id:"r1_g16_04", hebrew:"אֲנִי יוֹדֵעַ עִבְרִית!", plain:"אני יודע עברית", transliteration:"ани йодэа иврит!", translation:"я знаю иврит! (м.р.) — говори это после каждого урока", type:"phrase", lesson:"G1.6", audio:"r1_g16_04.mp3" },
      { id:"r1_g16_05", hebrew:"אֲנִי לֹא יָכוֹל", plain:"אני לא יכול", transliteration:"ани ло яхоль", translation:"я не могу (м.р.)", type:"phrase", lesson:"G1.6", audio:"r1_g16_05.mp3" },
    ],
    review: ["r1_g12_01", "r1_g12_04", "r1_g13_02", "rp_27"],
  },
  // ── C2 — открывается после урока ──
  { id:"R1.35", seq:135, lesson:"C2", title:"Вопрос интонацией",
    items: [
      { id:"r1_c2_01", hebrew:"?אַתָּה אוֹכֵל", plain:"אתה אוכל", transliteration:"ата охэль?", translation:"ты ешь? (м.р.) — интонация вверх", type:"phrase", lesson:"C2", audio:"r1_c2_01.mp3" },
      { id:"r1_c2_02", hebrew:"?אַתְּ רוֹצָה עוּגָה", plain:"את רוצה עוגה", transliteration:"ат роца уга?", translation:"ты хочешь торт? (ж.р.)", type:"phrase", lesson:"C2", audio:"r1_c2_02.mp3" },
      { id:"r1_c2_03", hebrew:"?הוּא הוֹלֵךְ", plain:"הוא הולך", transliteration:"hу hолех?", translation:"он идёт?", type:"phrase", lesson:"C2", audio:"r1_c2_03.mp3" },
      { id:"r1_c2_04", hebrew:"כֵּן, אֲנִי אוֹכֵל", plain:"כן אני אוכל", transliteration:"кэн, ани охэль", translation:"да, я ем (м.р.)", type:"phrase", lesson:"C2", audio:"r1_c2_04.mp3" },
    ],
    review: ["rw_20", "rw_08", "r1_g15_01"],
  },
  // ── CH1.4 — открывается после урока ──
  { id:"R1.36", seq:136, lesson:"CH1.4", title:"Числа 6–10 (ж.р.)",
    items: [
      { id:"r1_ch14_01", hebrew:"שֵׁשׁ", plain:"שש", transliteration:"шеш", translation:"шесть (ж.р.)", type:"word", lesson:"CH1.4", audio:"r1_ch14_01.mp3" },
      { id:"r1_ch14_02", hebrew:"שֶׁבַע", plain:"שבע", transliteration:"шева", translation:"семь (ж.р.)", type:"word", lesson:"CH1.4", audio:"r1_ch14_02.mp3" },
      { id:"r1_ch14_03", hebrew:"שְׁמוֹנֶה", plain:"שמונה", transliteration:"шмонэ", translation:"восемь (ж.р.)", type:"word", lesson:"CH1.4", audio:"r1_ch14_03.mp3", draft:true },
      { id:"r1_ch14_04", hebrew:"תֵּשַׁע", plain:"תשע", transliteration:"тэша", translation:"девять (ж.р.)", type:"word", lesson:"CH1.4", audio:"r1_ch14_04.mp3" },
      { id:"r1_ch14_05", hebrew:"עֶשֶׂר", plain:"עשר", transliteration:"эсер", translation:"десять (ж.р.)", type:"word", lesson:"CH1.4", audio:"r1_ch14_05.mp3" },
    ],
    review: ["r1_ch12_01", "r1_ch13_01", "r1_ch13_05"],
  },
  // ── Уровень 3 ──
  { id:"R1.37", seq:137, lesson:"M2.1", title:"Мн.ч. м.р. ־ים",
    items: [
      { id:"r1_m21_01", hebrew:"יְלָדִים", plain:"ילדים", transliteration:"йеладим", translation:"мальчики / дети", type:"word", lesson:"M2.1", audio:"r1_m21_01.mp3" },
      { id:"r1_m21_02", hebrew:"כְּלָבִים", plain:"כלבים", transliteration:"клавим", translation:"собаки", type:"word", lesson:"M2.1", audio:"r1_m21_02.mp3" },
      { id:"r1_m21_03", hebrew:"סְפָרִים", plain:"ספרים", transliteration:"сфарим", translation:"книги", type:"word", lesson:"M2.1", audio:"r1_m21_03.mp3" },
      { id:"r1_m21_04", hebrew:"תַּפּוּחִים", plain:"תפוחים", transliteration:"тапухим", translation:"яблоки", type:"word", lesson:"M2.1", audio:"r1_m21_04.mp3" },
      { id:"r1_m21_05", hebrew:"בָּתִּים", plain:"בתים", transliteration:"батим", translation:"дома (мн.ч.)", type:"word", lesson:"M2.1", audio:"r1_m21_05.mp3" },
    ],
    review: ["rw_16", "rw_23", "rw_31"],
  },
  { id:"R1.38", seq:138, lesson:"M2.2", title:"Мн.ч. ж.р. ־ות",
    items: [
      { id:"r1_m22_01", hebrew:"יְלָדוֹת", plain:"ילדות", transliteration:"еладот", translation:"девочки", type:"word", lesson:"M2.2", audio:"r1_m22_01.mp3" },
      { id:"r1_m22_02", hebrew:"מוֹרוֹת", plain:"מורות", transliteration:"морот", translation:"учительницы", type:"word", lesson:"M2.2", audio:"r1_m22_02.mp3" },
      { id:"r1_m22_03", hebrew:"עוּגוֹת", plain:"עוגות", transliteration:"угот", translation:"торты", type:"word", lesson:"M2.2", audio:"r1_m22_03.mp3" },
      { id:"r1_m22_04", hebrew:"יְלָדִים וִילָדוֹת", plain:"ילדים וילדות", transliteration:"йеладим ви-ладот", translation:"мальчики и девочки", type:"phrase", lesson:"M2.2", audio:"r1_m22_04.mp3", draft:true },
    ],
    review: ["rw_17", "r1_c0_03", "rw_33"],
  },
  { id:"R1.39", seq:139, lesson:"M2.3", title:"Нестандартные мн.ч.",
    items: [
      { id:"r1_m23_01", hebrew:"נָשִׁים", plain:"נשים", transliteration:"нашим", translation:"женщины (мн.ч. от אִישָּׁה)", type:"word", lesson:"M2.3", audio:"r1_m23_01.mp3" },
      { id:"r1_m23_02", hebrew:"אִישׁ", plain:"איש", transliteration:"иш", translation:"мужчина / человек", type:"word", lesson:"M2.3", audio:"r1_m23_02.mp3" },
      { id:"r1_m23_03", hebrew:"אֲנָשִׁים", plain:"אנשים", transliteration:"анашим", translation:"люди (мн.ч. от אִישׁ)", type:"word", lesson:"M2.3", audio:"r1_m23_03.mp3" },
      { id:"r1_m23_04", hebrew:"עָרִים", plain:"ערים", transliteration:"арим", translation:"города (ж.р. с окончанием ־ים!)", type:"word", lesson:"M2.3", audio:"r1_m23_04.mp3" },
    ],
    review: ["rw_15", "r1_m21_05", "r1_m12_04"],
  },
  { id:"R1.40", seq:140, lesson:"M2.4", title:"Предлог בְּ",
    items: [
      { id:"r1_m24_01", hebrew:"בַּבַּיִת", plain:"בבית", transliteration:"ба-байт", translation:"в доме / дома (בְּ+הַ=בַּ)", type:"word", lesson:"M2.4", audio:"r1_m24_01.mp3" },
      { id:"r1_m24_02", hebrew:"בָּעִיר", plain:"בעיר", transliteration:"ба-ир", translation:"в городе", type:"word", lesson:"M2.4", audio:"r1_m24_02.mp3" },
      { id:"r1_m24_03", hebrew:"הַיְּלָדִים בַּבַּיִת", plain:"הילדים בבית", transliteration:"hа-йеладим ба-байт", translation:"дети дома", type:"phrase", lesson:"M2.4", audio:"r1_m24_03.mp3" },
    ],
    review: ["r1_m11_01", "r1_m21_01", "r1_m12_04"],
  },
  { id:"R1.41", seq:141, lesson:"M2.5", title:"Предлог לְ",
    items: [
      { id:"r1_m25_01", hebrew:"לַבַּיִת", plain:"לבית", transliteration:"ла-байт", translation:"к дому / домой (לְ+הַ=לַ)", type:"word", lesson:"M2.5", audio:"r1_m25_01.mp3" },
      { id:"r1_m25_02", hebrew:"לָעִיר", plain:"לעיר", transliteration:"ла-ир", translation:"в город / к городу", type:"word", lesson:"M2.5", audio:"r1_m25_02.mp3" },
      { id:"r1_m25_03", hebrew:"אֲנִי הוֹלֵךְ לַבַּיִת", plain:"אני הולך לבית", transliteration:"ани hолех ла-байт", translation:"я иду домой (м.р.)", type:"phrase", lesson:"M2.5", audio:"r1_m25_03.mp3" },
    ],
    review: ["r1_m24_01", "rw_47", "r1_g13_01"],
  },
  { id:"R1.42", seq:142, lesson:"M2.6", title:"Предлог מִ",
    items: [
      { id:"r1_m26_01", hebrew:"רוּסְיָה", plain:"רוסיה", transliteration:"Русия", translation:"Россия", type:"word", lesson:"M2.6", audio:"r1_m26_01.mp3" },
      { id:"r1_m26_02", hebrew:"תֵּל אָבִיב", plain:"תל אביב", transliteration:"Тель-Авив", translation:"Тель-Авив", type:"word", lesson:"M2.6", audio:"r1_m26_02.mp3" },
      { id:"r1_m26_03", hebrew:"אֲנִי מֵרוּסְיָה", plain:"אני מרוסיה", transliteration:"ани мэ-Русия", translation:"я из России — фраза №1 каждого оле!", type:"phrase", lesson:"M2.6", audio:"r1_m26_03.mp3" },
      { id:"r1_m26_04", hebrew:"מֵהַבַּיִת", plain:"מהבית", transliteration:"мэ-hа-байт", translation:"из дома (артикль остаётся!)", type:"word", lesson:"M2.6", audio:"r1_m26_04.mp3" },
      { id:"r1_m26_05", hebrew:"הוּא מִתֵּל אָבִיב", plain:"הוא מתל אביב", transliteration:"hу ми-Тель-Авив", translation:"он из Тель-Авива", type:"phrase", lesson:"M2.6", audio:"r1_m26_05.mp3" },
    ],
    review: ["r1_m24_01", "r1_m25_01"],
  },
  { id:"R1.43", seq:143, lesson:"C3", title:"Предлоги с суффиксами",
    items: [
      { id:"r1_c3_01", hebrew:"לָנוּ", plain:"לנו", transliteration:"лану", translation:"нам", type:"word", lesson:"C3", audio:"r1_c3_01.mp3" },
      { id:"r1_c3_02", hebrew:"לָכֶם", plain:"לכם", transliteration:"лахэм", translation:"вам", type:"word", lesson:"C3", audio:"r1_c3_02.mp3" },
      { id:"r1_c3_03", hebrew:"לָהֶם", plain:"להם", transliteration:"лаhэм", translation:"им", type:"word", lesson:"C3", audio:"r1_c3_03.mp3" },
      { id:"r1_c3_04", hebrew:"יֵשׁ לָנוּ בַּיִת", plain:"יש לנו בית", transliteration:"еш лану байт", translation:"у нас есть дом", type:"phrase", lesson:"C3", audio:"r1_c3_04.mp3" },
      { id:"r1_c3_05", hebrew:"יֵשׁ לָהֶם יְלָדִים", plain:"יש להם ילדים", transliteration:"еш лаhэм йеладим", translation:"у них есть дети", type:"phrase", lesson:"C3", audio:"r1_c3_05.mp3" },
    ],
    review: ["r1_c1_01", "r1_c1_02"],
  },
  { id:"R1.44", seq:144, lesson:"M2.7", title:"Прилагательное — 4 формы",
    items: [
      { id:"r1_m27_01", hebrew:"גְּדוֹלִים", plain:"גדולים", transliteration:"гдолим", translation:"большие (м.мн.)", type:"word", lesson:"M2.7", audio:"r1_m27_01.mp3" },
      { id:"r1_m27_02", hebrew:"גְּדוֹלוֹת", plain:"גדולות", transliteration:"гдолот", translation:"большие (ж.мн.)", type:"word", lesson:"M2.7", audio:"r1_m27_02.mp3" },
      { id:"r1_m27_03", hebrew:"קְטַנָּה", plain:"קטנה", transliteration:"ктана", translation:"маленькая", type:"word", lesson:"M2.7", audio:"r1_m27_03.mp3" },
      { id:"r1_m27_04", hebrew:"בָּתִּים גְּדוֹלִים", plain:"בתים גדולים", transliteration:"батим гдолим", translation:"большие дома", type:"phrase", lesson:"M2.7", audio:"r1_m27_04.mp3" },
      { id:"r1_m27_05", hebrew:"יַלְדָּה קְטַנָּה", plain:"ילדה קטנה", transliteration:"ялда ктана", translation:"маленькая девочка", type:"phrase", lesson:"M2.7", audio:"r1_m27_05.mp3" },
    ],
    review: ["r1_c0_04", "r1_m14_02", "r1_m11_05"],
  },
  { id:"R1.45", seq:145, lesson:"M2.8", title:"Прилагательное с артиклем",
    items: [
      { id:"r1_m28_02", hebrew:"הַבַּיִת הַקָּטָן", plain:"הבית הקטן", transliteration:"hа-байт hа-катан", translation:"тот маленький дом", type:"phrase", lesson:"M2.8", audio:"r1_m28_02.mp3" },
      { id:"r1_m28_03", hebrew:"הַיַּלְדָּה הַקְּטַנָּה", plain:"הילדה הקטנה", transliteration:"hа-ялда hа-ктана", translation:"та маленькая девочка", type:"phrase", lesson:"M2.8", audio:"r1_m28_03.mp3" },
      { id:"r1_m28_04", hebrew:"הַבָּתִּים הַגְּדוֹלִים", plain:"הבתים הגדולים", transliteration:"hа-батим hа-гдолим", translation:"те большие дома", type:"phrase", lesson:"M2.8", audio:"r1_m28_04.mp3" },
    ],
    review: ["r1_m14_05", "r1_m14_03", "r1_m27_03"],
  },
  { id:"R1.46", seq:146, lesson:"M2.9", title:"Прямое дополнение אֶת",
    items: [
      { id:"r1_m29_01", hebrew:"אֲנִי אוֹכֵל אֶת הַלֶּחֶם", plain:"אני אוכל את הלחם", transliteration:"ани охэль эт hа-лэхем", translation:"я ем этот хлеб (את — маркер определённого)", type:"phrase", lesson:"M2.9", audio:"r1_m29_01.mp3" },
      { id:"r1_m29_02", hebrew:"הוּא רוֹאֶה אֶת הַכֶּלֶב", plain:"הוא רואה את הכלב", transliteration:"hу роэ эт hа-кэлев", translation:"он видит эту собаку", type:"phrase", lesson:"M2.9", audio:"r1_m29_02.mp3" },
      { id:"r1_m29_03", hebrew:"הִיא אוֹהֶבֶת אֶת הָעִיר", plain:"היא אוהבת את העיר", transliteration:"hи оhевет эт hа-ир", translation:"она любит этот город", type:"phrase", lesson:"M2.9", audio:"r1_m29_03.mp3" },
    ],
    review: ["rw_09", "r1_m11_03", "r1_g13_04"],
  },
  { id:"R1.47", seq:147, lesson:"G2.1", title:"Глаголы мн.ч. м.р.",
    items: [
      { id:"r1_g21_01", hebrew:"הוֹלְכִים", plain:"הולכים", transliteration:"hолхим", translation:"идут (м.мн.)", type:"word", lesson:"G2.1", audio:"r1_g21_01.mp3" },
      { id:"r1_g21_02", hebrew:"אוֹכְלִים", plain:"אוכלים", transliteration:"охлим", translation:"едят (м.мн.)", type:"word", lesson:"G2.1", audio:"r1_g21_02.mp3" },
      { id:"r1_g21_03", hebrew:"גָּרִים", plain:"גרים", transliteration:"гарим", translation:"живут (м.мн.)", type:"word", lesson:"G2.1", audio:"r1_g21_03.mp3" },
      { id:"r1_g21_04", hebrew:"אֲנַחְנוּ הוֹלְכִים", plain:"אנחנו הולכים", transliteration:"анахну hолхим", translation:"мы идём", type:"phrase", lesson:"G2.1", audio:"r1_g21_04.mp3" },
      { id:"r1_g21_05", hebrew:"הֵם גָּרִים בָּעִיר", plain:"הם גרים בעיר", transliteration:"hэм гарим ба-ир", translation:"они живут в городе", type:"phrase", lesson:"G2.1", audio:"r1_g21_05.mp3" },
    ],
    review: ["rp_24", "rp_25", "rw_47"],
  },
  { id:"R1.48", seq:148, lesson:"G2.2", title:"Глаголы мн.ч. ж.р.",
    items: [
      { id:"r1_g22_01", hebrew:"הֵן", plain:"הן", transliteration:"hэн", translation:"они (о женщинах)", type:"word", lesson:"G2.2", audio:"r1_g22_01.mp3" },
      { id:"r1_g22_02", hebrew:"הוֹלְכוֹת", plain:"הולכות", transliteration:"hолхот", translation:"идут (ж.мн.)", type:"word", lesson:"G2.2", audio:"r1_g22_02.mp3" },
      { id:"r1_g22_03", hebrew:"אוֹכְלוֹת", plain:"אוכלות", transliteration:"охлот", translation:"едят (ж.мн.)", type:"word", lesson:"G2.2", audio:"r1_g22_03.mp3" },
      { id:"r1_g22_04", hebrew:"הֵן הוֹלְכוֹת לָעִיר", plain:"הן הולכות לעיר", transliteration:"hэн hолхот ла-ир", translation:"они (ж.) идут в город — Майя и Тамар", type:"phrase", lesson:"G2.2", audio:"r1_g22_04.mp3" },
    ],
    review: ["rp_25", "r1_g21_01", "r1_m25_02"],
  },
  { id:"R1.49", seq:149, lesson:"G2.3", title:"Полная таблица настоящего",
    items: [
      { id:"r1_g23_01", hebrew:"שׁוֹתִים", plain:"שותים", transliteration:"шотим", translation:"пьют (м.мн.)", type:"word", lesson:"G2.3", audio:"r1_g23_01.mp3" },
      { id:"r1_g23_02", hebrew:"רוֹצִים", plain:"רוצים", transliteration:"роцим", translation:"хотят (м.мн.)", type:"word", lesson:"G2.3", audio:"r1_g23_02.mp3" },
      { id:"r1_g23_03", hebrew:"אֲנַחְנוּ רוֹצִים מַיִם", plain:"אנחנו רוצים מים", transliteration:"анахну роцим маим", translation:"мы хотим воды", type:"phrase", lesson:"G2.3", audio:"r1_g23_03.mp3" },
    ],
    review: ["rw_50", "rw_52", "r1_g21_02"],
  },
  { id:"R1.50", seq:150, lesson:"G2.4", title:"Полное спряжение — синтез",
    items: [
      { id:"r1_g24_01", hebrew:"יוֹדְעִים", plain:"יודעים", transliteration:"йодъим", translation:"знают (м.мн.)", type:"word", lesson:"G2.4", audio:"r1_g24_01.mp3" },
      { id:"r1_g24_02", hebrew:"יְכוֹלִים", plain:"יכולים", transliteration:"ехолим", translation:"могут (м.мн.)", type:"word", lesson:"G2.4", audio:"r1_g24_02.mp3" },
      { id:"r1_g24_03", hebrew:"אוֹהֲבִים", plain:"אוהבים", transliteration:"оhавим", translation:"любят (м.мн.)", type:"word", lesson:"G2.4", audio:"r1_g24_03.mp3" },
      { id:"r1_g24_04", hebrew:"אֲנַחְנוּ אוֹהֲבִים אֶת הָעִיר", plain:"אנחנו אוהבים את העיר", transliteration:"анахну оhавим эт hа-ир", translation:"мы любим этот город", type:"phrase", lesson:"G2.4", audio:"r1_g24_04.mp3" },
      { id:"r1_g24_05", hebrew:"הֵם יוֹדְעִים עִבְרִית", plain:"הם יודעים עברית", transliteration:"hэм йодъим иврит", translation:"они знают иврит", type:"phrase", lesson:"G2.4", audio:"r1_g24_05.mp3" },
    ],
    review: ["r1_g12_03", "r1_g12_04", "r1_g16_03", "rp_27"],
  },
  { id:"R1.51", seq:151, lesson:"C4", title:"Связка שֶׁ",
    items: [
      { id:"r1_c4_01", hebrew:"הַכֶּלֶב שֶׁאֲנִי אוֹהֵב", plain:"הכלב שאני אוהב", transliteration:"hа-кэлев ше-ани оhев", translation:"собака, которую я люблю", type:"phrase", lesson:"C4", audio:"r1_c4_01.mp3" },
      { id:"r1_c4_02", hebrew:"הָעוּגָה שֶׁאֲנִי אוֹכֵל", plain:"העוגה שאני אוכל", transliteration:"hа-уга ше-ани охэль", translation:"торт, который я ем", type:"phrase", lesson:"C4", audio:"r1_c4_02.mp3" },
      { id:"r1_c4_03", hebrew:"הַיְּלָדִים שֶׁגָּרִים בָּעִיר", plain:"הילדים שגרים בעיר", transliteration:"hа-йеладим ше-гарим ба-ир", translation:"дети, которые живут в городе", type:"phrase", lesson:"C4", audio:"r1_c4_03.mp3" },
    ],
    review: ["rw_46", "r1_g21_03"],
  },
  { id:"R1.52", seq:152, lesson:"CH2.1", title:"Числа 11–20",
    items: [
      { id:"r1_ch21_01", hebrew:"אַחַת עֶשְׂרֵה", plain:"אחת עשרה", transliteration:"ахат эсрэ", translation:"одиннадцать", type:"word", lesson:"CH2.1", audio:"r1_ch21_01.mp3" },
      { id:"r1_ch21_02", hebrew:"שְׁתֵּים עֶשְׂרֵה", plain:"שתים עשרה", transliteration:"штэйм эсрэ", translation:"двенадцать", type:"word", lesson:"CH2.1", audio:"r1_ch21_02.mp3" },
      { id:"r1_ch21_03", hebrew:"שְׁלֹשׁ עֶשְׂרֵה", plain:"שלש עשרה", transliteration:"шалош эсрэ", translation:"тринадцать", type:"word", lesson:"CH2.1", audio:"r1_ch21_03.mp3" },
      { id:"r1_ch21_04", hebrew:"חֲמֵשׁ עֶשְׂרֵה", plain:"חמש עשרה", transliteration:"хамэш эсрэ", translation:"пятнадцать", type:"word", lesson:"CH2.1", audio:"r1_ch21_04.mp3", draft:true },
      { id:"r1_ch21_05", hebrew:"עֶשְׂרִים", plain:"עשרים", transliteration:"эсрим", translation:"двадцать", type:"word", lesson:"CH2.1", audio:"r1_ch21_05.mp3" },
    ],
    review: ["r1_ch12_01", "r1_ch14_05"],
  },
  {"id": "R1.53", "seq": 53, "lesson": "M3.1", "title": "Семья и вещи — чьё это?", "items": [{"id": "r1_m31_01", "hebrew": "אָח", "plain": "אח", "transliteration": "ах", "translation": "брат — старший брат в семье называется הָאָח הַגָּדוֹל", "type": "noun", "lesson": "M3.1", "audio": "r1_m31_01.mp3", "draft": true}, {"id": "r1_m31_02", "hebrew": "אָחוֹת", "plain": "אחות", "transliteration": "ахот", "translation": "сестра — Тамар это אָחוֹת Ноама", "type": "noun", "lesson": "M3.1", "audio": "r1_m31_02.mp3", "draft": true}, {"id": "r1_m31_03", "hebrew": "סַבָּא", "plain": "סבא", "transliteration": "саба", "translation": "дедушка", "type": "noun", "lesson": "M3.1", "audio": "r1_m31_03.mp3", "draft": true}, {"id": "r1_m31_04", "hebrew": "סַבְתָּא", "plain": "סבתא", "transliteration": "савта", "translation": "бабушка", "type": "noun", "lesson": "M3.1", "audio": "r1_m31_04.mp3", "draft": true}, {"id": "r1_m31_05", "hebrew": "מִשְׁפָּחָה", "plain": "משפחה", "transliteration": "мишпаха", "translation": "семья — окончание ה, женский род", "type": "noun", "lesson": "M3.1", "audio": "r1_m31_05.mp3", "draft": true}, {"id": "r1_m31_06", "hebrew": "חָבֵר", "plain": "חבר", "transliteration": "хавер", "translation": "друг — модель, знакомая по SL: «тот, кто дружит»", "type": "noun", "lesson": "M3.1", "audio": "r1_m31_06.mp3", "draft": true}, {"id": "r1_m31_07", "hebrew": "טֶלֶפוֹן", "plain": "טלפון", "transliteration": "телефон", "translation": "телефон — звучит почти как по-русски", "type": "noun", "lesson": "M3.1", "audio": "r1_m31_07.mp3", "draft": true}], "review": ["rw_10", "rw_01", "r1_m21_01", "rw_23"]},
];

// ─── Совместимость: плоские экспорты ─────────────────────────────────────────
// ─── Фразы-замки зоны 0 («ты уже можешь сказать») ────────────────────────────
// Живые фразы, собранные ТОЛЬКО из слов зоны 0 (метод Коэн-Цедека: фразы раньше
// теории). Фраза «замыкается», когда все слова из composedOf изучены
// (readingProgress.studied). Не гейтят прогрессию — это награда за словарь.
export const PHRASE_LOCKS = [
  { id:"pl_01", hebrew:"זֶה טוֹב", plain:"זה טוב", transliteration:"зэ тов", translation:"это хорошо", composedOf:["rw_18","rw_32"], audio:"pl_01.mp3" },
  { id:"pl_02", hebrew:"זֶה לֹא טוֹב", plain:"זה לא טוב", transliteration:"зэ ло тов", translation:"это нехорошо", composedOf:["rw_18","rw_08","rw_32"], audio:"pl_02.mp3" },
  { id:"pl_03", hebrew:"חַג שָׂמֵחַ!", plain:"חג שמח", transliteration:"хаг самэах!", translation:"весёлого праздника! — главное израильское поздравление", composedOf:["rw_54","rw_24"], audio:"pl_03.mp3" },
  { id:"pl_04", hebrew:"אֲנִי רוֹצֶה מַיִם", plain:"אני רוצה מים", transliteration:"ани роцэ маим", translation:"я хочу воды", composedOf:["rw_04","rw_52","rw_03"], audio:"pl_04.mp3" },
  { id:"pl_05", hebrew:"אֲנִי הוֹלֵךְ", plain:"אני הולך", transliteration:"ани hолех", translation:"я иду", composedOf:["rw_04","rw_47"], audio:"pl_05.mp3" },
  { id:"pl_06", hebrew:"אִימָא בָּאָה", plain:"אימא באה", transliteration:"има баа", translation:"мама идёт (сюда)", composedOf:["rw_01","rw_45"], audio:"pl_06.mp3" },
  { id:"pl_07", hebrew:"אַבָּא אוֹכֵל לֶחֶם", plain:"אבא אוכל לחם", transliteration:"аба охэль лэхем", translation:"папа ест хлеб", composedOf:["rw_10","rw_48","rw_09"], audio:"pl_07.mp3" },
  { id:"pl_08", hebrew:"?אַתָה רוֹצֶה מִיץ", plain:"אתה רוצה מיץ", transliteration:"ата роцэ миц?", translation:"ты хочешь сок? (м.р.)", composedOf:["rw_06","rw_52","rw_29"], audio:"pl_08.mp3" },
  { id:"pl_09", hebrew:"כֵּן, אֲנִי רוֹצֶה", plain:"כן אני רוצה", transliteration:"кэн, ани роцэ", translation:"да, я хочу", composedOf:["rw_20","rw_04","rw_52"], audio:"pl_09.mp3" },
  { id:"pl_10", hebrew:"הִיא יַלְדָה", plain:"היא ילדה", transliteration:"hи ялда", translation:"она — девочка", composedOf:["rw_07","rw_17"], audio:"pl_10.mp3" },
  { id:"pl_11", hebrew:"יֶלֶד אוֹכֵל תַּפּוּחַ", plain:"ילד אוכל תפוח", transliteration:"йэлед охэль тапуах", translation:"мальчик ест яблоко", composedOf:["rw_16","rw_48","rw_41"], audio:"pl_11.mp3" },
  { id:"pl_12", hebrew:"כֶּלֶב רוֹאֶה עוֹף", plain:"כלב רואה עוף", transliteration:"кэлев роэ оф", translation:"собака видит птицу — Рекс на прогулке!", composedOf:["rw_23","rw_49","rw_42"], audio:"pl_12.mp3" },
  { id:"pl_13", hebrew:"חָלָב חַם", plain:"חלב חם", transliteration:"халав хам", translation:"горячее молоко", composedOf:["rw_11","rw_13"], audio:"pl_13.mp3" },
  { id:"pl_14", hebrew:"מִיץ טָעִים", plain:"מיץ טעים", transliteration:"миц таим", translation:"вкусный сок", composedOf:["rw_29","rw_39"], audio:"pl_14.mp3" },
  { id:"pl_15", hebrew:"זֹאת אַהֲבָה", plain:"זאת אהבה", transliteration:"зот аhава", translation:"это любовь", composedOf:["rw_19","rw_12"], audio:"pl_15.mp3" },
  { id:"pl_16", hebrew:"אֲנִי קוֹרֵא סֵפֶר", plain:"אני קורא ספר", transliteration:"ани корэ сэфер", translation:"я читаю книгу", composedOf:["rw_04","rw_51","rw_31"], audio:"pl_16.mp3" },
];

/** Фразы-замки, все слова которых уже изучены (composedOf ⊆ studied). */
export function getUnlockedPhraseLocks(studied = []) {
  const set = new Set(studied);
  return PHRASE_LOCKS.filter(p => p.composedOf.every(id => set.has(id)));
}

export const READING_ITEMS   = READING_BLOCKS.flatMap(b => b.items);
export const READING_WORDS   = READING_ITEMS.filter(w => w.type !== 'phrase');
export const READING_PHRASES = READING_ITEMS.filter(w => w.type === 'phrase');

/** Карточки блока с повторением: собственные items + review-карточки по ссылкам */
const ITEMS_BY_ID = Object.fromEntries(READING_ITEMS.map(i => [i.id, i]));
export function getBlockCards(block) {
  const review = (block.review || []).map(id => ITEMS_BY_ID[id]).filter(Boolean)
    .map(i => ({ ...i, isReview: true }));
  return [...block.items, ...review];
}
